<div id="header"> <span class="logo"><img src="{{ asset('images/frontend_images/logo.gif') }}" alt="" /></span>
        <p>1498 <span>members online now,</span> 210 <span>new profiles this week,</span> 46,786 <span>total members till today !</span></p>
        <div id="menu">
          <ul>
            <li class="first"><a class="current" href="{{ url('/') }}">home</a></li>
            <li><a href="about_us.html">about us</a></li>
            <li><a href="privacy.html">privacy</a></li>
            <li><a href="projects.html">projects</a></li>
            <li><a href="services.html">services</a></li>
            <li><a href="support.html">support</a></li>
            <li><a href="contact_us.html">contact Us</a></li>
          </ul>
        </div>
      </div>