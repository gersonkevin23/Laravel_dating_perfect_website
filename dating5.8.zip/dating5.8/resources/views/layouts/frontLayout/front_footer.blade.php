<div id="footer">
	<div class="footer_link">
	  <ul>
	    Copyright (c) Sitename.com. All rights reserved. Design by Stylish <a href="http://www.stylishtemplate.com">Website Templates</a>.
	  </ul>
	</div>
</div>