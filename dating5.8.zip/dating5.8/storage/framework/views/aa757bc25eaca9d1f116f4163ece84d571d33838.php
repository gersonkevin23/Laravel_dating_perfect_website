<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Love Story</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/backend_css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/backend_css/bootstrap-responsive.min.css')); ?>" />
<link href="<?php echo e(asset('css/frontend_css/layout.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
<script src="<?php echo e(asset('js/frontend_js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/main.js')); ?>"></script>
<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/frontend_js/slide.js')); ?>"></script>
<script>
  $(function() {
    $( "#dob" ).datepicker({ 
      dateFormat:'yy-mm-dd',
    	changeMonth: true,
      changeYear: true,
    	maxDate: '0',
    	yearRange: '1950:2018' 
    });
  });
</script>
</head>
<body>
<div id="layout">
  <div class="layout_inner">
    <div id="body_container">
      <?php echo $__env->make('layouts.frontLayout.front_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php echo $__env->make('layouts.frontLayout.front_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </div>
  <?php echo $__env->make('layouts.frontLayout.front_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
</div>
</body>
</html>
