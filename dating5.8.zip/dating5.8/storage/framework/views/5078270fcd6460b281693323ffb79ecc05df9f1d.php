<?php $__env->startSection('content'); ?>
<div id="right_container">
    <div style="padding:20px 15px 30px 15px;">
        <h1>Review Profile</h1>
        <h2>Your profile under review !!</h2>
        <div> <strong> <br />
            As part of the process, we screen every profile to ensure whether it meets our terms and conditions. You will receive a mail from us on your profile status as soon as screening is complete. </strong><br />
        </div>
        <div>
        </div>
    </div>
    <div class="clear"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>