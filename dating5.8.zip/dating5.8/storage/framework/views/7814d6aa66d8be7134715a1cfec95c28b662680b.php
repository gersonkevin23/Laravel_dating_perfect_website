<?php /* F:\xampp\htdocs\laravel\dating5.8\resources\views/users/step2.blade.php */ ?>
<?php 
use App\User; 
$datingCount = User::datingProfileExists(Auth::User()['id']);
if($datingCount==1){
    $datingCountText = "My Dating Profile";
    $datingCountText2 = "Update Dating profile below:- ";
} else {
    $datingCountText = "Add Dating Profile";
    $datingCountText2 = "Add Dating profile by filling out the form below:- ";
}
$datingProfile = User::datingProfileDetails(Auth::User()['id']);
/*$datingProfile = json_decode(json_encode($datingProfile));
echo "<pre>"; print_r($datingProfile); die;*/
?>

<?php $__env->startSection('content'); ?>
<div id="right_container">
    <div style="padding:20px 15px 30px 15px;">
        <h1><?php echo e($datingCountText); ?></h1>
        <div> <strong> <br />
            <?php echo e($datingCountText2); ?></strong><br />
        </div>
        <div>
            <br />
            <h6 class="inner">Personal Information</h6>
            <br />
            <form id="datingForm" name="datingForm" action="<?php echo e(url('/step/2')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php if(!empty($datingProfile->user_id)): ?>
                    <input type="hidden" name="user_id" value="<?php echo e($datingProfile->user_id); ?>">
                <?php endif; ?>
                <table width="80%" cellpadding="10" cellspacing="10">
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Date of Birth: * </strong></td>
                        <td align="left" valign="top"><input autocomplete="off" id="dob" name="dob" <?php if(!empty($datingProfile['dob'])): ?> value="<?php echo e($datingProfile['dob']); ?>" <?php endif; ?> type="text" style="width:200px; font-size: 14px" /></td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Gender: * </strong></td>
                        <td align="left" valign="top">
                            <select name="gender" style="width:208px; font-size: 14px; height: 25px;">
                                <option>Select</option>
                                <option value="Male" <?php if(!empty($datingProfile['gender']) && $datingProfile['gender']=="Male"): ?> selected="" <?php endif; ?>>Male</option>
                                <option value="Female" <?php if(!empty($datingProfile['gender']) && $datingProfile['gender']=="Female"): ?> selected="" <?php endif; ?>>Female</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Height: * </strong></td>
                        <td align="left" valign="top">
                            <select name="height" style="width:208px; font-size: 14px; height: 25px;">
                                <option value="">Feet/Inches</option>
                                <option value="4' 0'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 0'"): ?> selected="" <?php endif; ?>>4' 0"</option>
                                <option value="4' 1'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 1'"): ?> selected="" <?php endif; ?>>4' 1"</option>
                                <option value="4' 2'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 2'"): ?> selected="" <?php endif; ?>>4' 2"</option>
                                <option value="4' 3'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 3'"): ?> selected="" <?php endif; ?>>4' 3"</option>
                                <option value="4' 4'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 4'"): ?> selected="" <?php endif; ?>>4' 4"</option>
                                <option value="4' 5'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 5'"): ?> selected="" <?php endif; ?>>4' 5"</option>
                                <option value="4' 6'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 6'"): ?> selected="" <?php endif; ?>>4' 6"</option>
                                <option value="4' 7'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 7'"): ?> selected="" <?php endif; ?>>4' 7"</option>
                                <option value="4' 8'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 8'"): ?> selected="" <?php endif; ?>>4' 8"</option>
                                <option value="4' 9'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 9'"): ?> selected="" <?php endif; ?>>4' 9"</option>
                                <option value="4' 10'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 10'"): ?> selected="" <?php endif; ?>>4' 10"</option>
                                <option value="4' 11'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="4' 11'"): ?> selected="" <?php endif; ?>>4' 11"</option>
                                <option value="5' 0'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 0'"): ?> selected="" <?php endif; ?>>5' 0"</option>
                                <option value="5' 1'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 1'"): ?> selected="" <?php endif; ?>>5' 1"</option>
                                <option value="5' 2'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 2'"): ?> selected="" <?php endif; ?>>5' 2"</option>
                                <option value="5' 3'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 3'"): ?> selected="" <?php endif; ?>>5' 3"</option>
                                <option value="5' 4'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 4'"): ?> selected="" <?php endif; ?>>5' 4"</option>
                                <option value="5' 5'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 5'"): ?> selected="" <?php endif; ?>>5' 5"</option>
                                <option value="5' 6'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 6'"): ?> selected="" <?php endif; ?>>5' 6"</option>
                                <option value="5' 7'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 7'"): ?> selected="" <?php endif; ?>>5' 7"</option>
                                <option value="5' 8'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 8'"): ?> selected="" <?php endif; ?>>5' 8"</option>
                                <option value="5' 9'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 9'"): ?> selected="" <?php endif; ?>>5' 9"</option>
                                <option value="5' 10'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 10'"): ?> selected="" <?php endif; ?>>5' 10"</option>
                                <option value="5' 11'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="5' 11'"): ?> selected="" <?php endif; ?>>5' 11"</option>
                                <option value="6' 0'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 0'"): ?> selected="" <?php endif; ?>>6' 0"</option>
                                <option value="6' 1'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 1'"): ?> selected="" <?php endif; ?>>6' 1"</option>
                                <option value="6' 2'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 2'"): ?> selected="" <?php endif; ?>>6' 2"</option>
                                <option value="6' 3'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 3'"): ?> selected="" <?php endif; ?>>6' 3"</option>
                                <option value="6' 4'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 4'"): ?> selected="" <?php endif; ?>>6' 4"</option>
                                <option value="6' 5'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 5'"): ?> selected="" <?php endif; ?>>6' 5"</option>
                                <option value="6' 6'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 6'"): ?> selected="" <?php endif; ?>>6' 6"</option>
                                <option value="6' 7'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 7'"): ?> selected="" <?php endif; ?>>6' 7"</option>
                                <option value="6' 8'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 8'"): ?> selected="" <?php endif; ?>>6' 8"</option>
                                <option value="6' 9'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 9'"): ?> selected="" <?php endif; ?>>6' 9"</option>
                                <option value="6' 10'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 10'"): ?> selected="" <?php endif; ?>>6' 10"</option>
                                <option value="6' 11'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="6' 11'"): ?> selected="" <?php endif; ?>>6' 11"</option>
                                <option value="7' 0'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 0'"): ?> selected="" <?php endif; ?>>7' 0"</option>
                                <option value="7' 1'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 1'"): ?> selected="" <?php endif; ?>>7' 1"</option>
                                <option value="7' 2'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 2'"): ?> selected="" <?php endif; ?>>7' 2"</option>
                                <option value="7' 3'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 3'"): ?> selected="" <?php endif; ?>>7' 3"</option>
                                <option value="7' 4'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 4'"): ?> selected="" <?php endif; ?>>7' 4"</option>
                                <option value="7' 5'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 5'"): ?> selected="" <?php endif; ?>>7' 5"</option>
                                <option value="7' 6'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 6'"): ?> selected="" <?php endif; ?>>7' 6"</option>
                                <option value="7' 7'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 7'"): ?> selected="" <?php endif; ?>>7' 7"</option>
                                <option value="7' 8'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 8'"): ?> selected="" <?php endif; ?>>7' 8"</option>
                                <option value="7' 9'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 9'"): ?> selected="" <?php endif; ?>>7' 9"</option>
                                <option value="7' 10'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 10'"): ?> selected="" <?php endif; ?>>7' 10"</option>
                                <option value="7' 11'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="7' 11'"): ?> selected="" <?php endif; ?>>7' 11"</option>
                                <option value="8' 0'" <?php if(!empty($datingProfile['height']) && $datingProfile['height']=="8' 0'"): ?> selected="" <?php endif; ?>>8' 0"</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Marital Status: * </strong></td>
                        <td align="left" valign="top">
                            <select name="marital_status" style="width:208px; font-size: 14px; height: 25px;">
                                <option value="">Select</option>
                                <option value="Unmarried" <?php if(!empty($datingProfile['marital_status']) && $datingProfile['marital_status']=="Unmarried"): ?> selected="" <?php endif; ?>>Unmarried</option>
                                <option value="Married"  <?php if(!empty($datingProfile['marital_status']) && $datingProfile['marital_status']=="Married"): ?> selected="" <?php endif; ?>>Married</option>
                                <option value="Divorced"  <?php if(!empty($datingProfile['marital_status']) && $datingProfile['marital_status']=="Divorced"): ?> selected="" <?php endif; ?>>Divorced</option>
                                <option value="Widowed"  <?php if(!empty($datingProfile['marital_status']) && $datingProfile['marital_status']=="Widowed"): ?> selected="" <?php endif; ?>>Widowed</option>
                                <option value="Seperated"  <?php if(!empty($datingProfile['marital_status']) && $datingProfile['marital_status']=="Seperated"): ?> selected="" <?php endif; ?>>Seperated</option>
                                <option value="Annulled"  <?php if(!empty($datingProfile['marital_status']) && $datingProfile['marital_status']=="Annulled"): ?> selected="" <?php endif; ?>>Annulled</option>
                                <option value="Other"  <?php if(!empty($datingProfile['marital_status']) && $datingProfile['marital_status']=="Other"): ?> selected="" <?php endif; ?>>Other</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Body Type: </strong></td>
                        <td align="left" valign="top">
                            <select name="body_type" style="width:208px; font-size: 14px; height: 25px;">
                                <option value="">Select</option>
                                <option value="Slim" <?php if(!empty($datingProfile['body_type']) && $datingProfile['body_type']=="Slim"): ?> selected="" <?php endif; ?>>Slim</option>
                                <option value="Average" <?php if(!empty($datingProfile['body_type']) && $datingProfile['body_type']=="Average"): ?> selected="" <?php endif; ?>>Average</option>
                                <option value="Athletic" <?php if(!empty($datingProfile['body_type']) && $datingProfile['body_type']=="Athletic"): ?> selected="" <?php endif; ?>>Athletic</option>
                                <option value="Heavy" <?php if(!empty($datingProfile['body_type']) && $datingProfile['body_type']=="Heavy"): ?> selected="" <?php endif; ?>>Heavy</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Complexion: </strong></td>
                        <td align="left" valign="top">
                            <select name="complexion" style="width:208px; font-size: 14px; height: 25px;">
                                <option value="">Select</option>
                                <option value="Very Fair" <?php if(!empty($datingProfile['complexion']) && $datingProfile['complexion']=="Very Fair"): ?> selected="" <?php endif; ?>>Very Fair</option>
                                <option value="Fair" <?php if(!empty($datingProfile['complexion']) && $datingProfile['complexion']=="Fair"): ?> selected="" <?php endif; ?>>Fair</option>
                                <option value="Wheatish" <?php if(!empty($datingProfile['complexion']) && $datingProfile['complexion']=="Wheatish"): ?> selected="" <?php endif; ?>>Wheatish</option>
                                <option value="Dark" <?php if(!empty($datingProfile['complexion']) && $datingProfile['complexion']=="Dark"): ?> selected="" <?php endif; ?>>Dark</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> City: </strong></td>
                        <td align="left" valign="top"><input autocomplete="off" id="city" name="city" <?php if(!empty($datingProfile['city'])): ?> value="<?php echo e($datingProfile['city']); ?>" <?php endif; ?> type="text" style="width:200px; font-size: 14px" /></td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> State: </strong></td>
                        <td align="left" valign="top"><input autocomplete="off" id="state" name="state" <?php if(!empty($datingProfile['state'])): ?> value="<?php echo e($datingProfile['state']); ?>" <?php endif; ?> type="text" style="width:200px; font-size: 14px" /></td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Country: </strong></td>
                        <td align="left" valign="top">
                            <select name="country" style="width:208px; font-size: 14px; height: 25px;">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->name); ?>" <?php if(!empty($datingProfile['country']) && $datingProfile['country']==$country->name): ?> selected="" <?php endif; ?>><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Languages: </strong></td>
                        <td align="left" valign="top">
                            <select name="languages[]" multiple style="width:208px; font-size: 14px; height: 100px;">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($language->name); ?>" <?php if(!empty($datingProfile->languages) && preg_match('/'.$language->name.'/i', $datingProfile->languages)){ echo "selected"; } ?>><?php echo e($language->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Hobbies: </strong></td>
                        <td align="left" valign="top">
                            <select name="hobbies[]" multiple style="width:208px; font-size: 14px; height: 100px;">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($hobby->title); ?>" <?php if(!empty($datingProfile->hobbies) && preg_match('/'.$hobby->title.'/i', $datingProfile->hobbies)){ echo "selected"; } ?>><?php echo e($hobby->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><h6 class="inner">Education & Career</h6></td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Highest Education: </strong></td>
                        <td align="left" valign="top"><input autocomplete="off" id="education" name="education" <?php if(!empty($datingProfile['education'])): ?> value="<?php echo e($datingProfile['education']); ?>" <?php endif; ?> type="text" style="width:200px; font-size: 14px" /></td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Occupation: </strong></td>
                        <td align="left" valign="top">
                            <select name="occupation" style="width:208px; font-size: 14px; height: 25px;">
                                <option value="">Select</option>
                                <option value="Student" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Student"): ?> selected="" <?php endif; ?>>Student</option>
                                <option value="Not working" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Not working"): ?> selected="" <?php endif; ?>>Not working</option>
                                <option value="Non-mainstream" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Student"): ?> selected="" <?php endif; ?>>Non-mainstream</option>
                                <option value="Accountant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Accountant"): ?> selected="" <?php endif; ?>>Accountant</option>
                                <option value="Acting" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Acting"): ?> selected="" <?php endif; ?>>Acting</option>
                                <option value="Actor" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Actor"): ?> selected="" <?php endif; ?>>Actor</option>
                                <option value="Administration" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Administration"): ?> selected="" <?php endif; ?>>Administration</option>
                                <option value="Advertising" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Advertising"): ?> selected="" <?php endif; ?>>Advertising</option>
                                <option value="Advocate" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Advocate"): ?> selected="" <?php endif; ?>>Advocate</option>
                                <option value="Air Hostess" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Air Hostess"): ?> selected="" <?php endif; ?>>Air Hostess</option>
                                <option value="Airlines" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Airlines"): ?> selected="" <?php endif; ?>>Airlines</option>
                                <option value="Architect" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Architect"): ?> selected="" <?php endif; ?>>Architect</option>
                                <option value="Artisan" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Artisan"): ?> selected="" <?php endif; ?>>Artisan</option>
                                <option value="Audiologist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Audiologist"): ?> selected="" <?php endif; ?>>Audiologist</option>
                                <option value="Banker" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Banker"): ?> selected="" <?php endif; ?>>Banker</option>
                                <option value="Beautician" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Beautician"): ?> selected="" <?php endif; ?>>Beautician</option>
                                <option value="Biologist/Botanist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Biologist/Botanist"): ?> selected="" <?php endif; ?>>Biologist/Botanist</option>
                                <option value="Business Person" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Business Person"): ?> selected="" <?php endif; ?>>Business Person</option>
                                <option value="Chartered Accountant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Chartered Accountant"): ?> selected="" <?php endif; ?>>Chartered Accountant</option>
                                <option value="Chemist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Chemist"): ?> selected="" <?php endif; ?>>Chemist</option>
                                <option value="Civil Engineer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Civil Engineer"): ?> selected="" <?php endif; ?>>Civil Engineer</option>
                                <option value="Clerical Official" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Clerical Official"): ?> selected="" <?php endif; ?>>Clerical Official</option>
                                <option value="Commercial Pilot" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Commercial Pilot"): ?> selected="" <?php endif; ?>>Commercial Pilot</option>
                                <option value="Company Secretary" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Company Secretary"): ?> selected="" <?php endif; ?>>Company Secretary</option>
                                <option value="Computer Professional" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Computer Professional"): ?> selected="" <?php endif; ?>>Computer Professional</option>
                                <option value="Consultant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Consultant"): ?> selected="" <?php endif; ?>>Consultant</option>
                                <option value="Contractor" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Contractor"): ?> selected="" <?php endif; ?>>Contractor</option>
                                <option value="Cost Accountant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Cost Accountant"): ?> selected="" <?php endif; ?>>Cost Accountant</option>
                                <option value="Creative Person" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Creative Person"): ?> selected="" <?php endif; ?>>Creative Person</option>
                                <option value="Customer Support" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Customer Support"): ?> selected="" <?php endif; ?>>Customer Support</option>
                                <option value="Defence Employee" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Defence Employee"): ?> selected="" <?php endif; ?>>Defence Employee</option>
                                <option value="Dentist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Dentist"): ?> selected="" <?php endif; ?>>Dentist</option>
                                <option value="Designer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Designer"): ?> selected="" <?php endif; ?>>Designer</option>
                                <option value="Doctor" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Doctor"): ?> selected="" <?php endif; ?>>Doctor</option>
                                <option value="Economist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Economist"): ?> selected="" <?php endif; ?>>Economist</option>
                                <option value="Engineer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Engineer"): ?> selected="" <?php endif; ?>>Engineer</option>
                                <option value="Engineer (Mechanical)" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Engineer (Mechanical)"): ?> selected="" <?php endif; ?>>Engineer (Mechanical)</option>
                                <option value="Engineer (Project)" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Engineer (Project)"): ?> selected="" <?php endif; ?>>Engineer (Project)</option>
                                <option value="Entertainment" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Entertainment"): ?> selected="" <?php endif; ?>>Entertainment</option>
                                <option value="Event Manager" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Event Manager"): ?> selected="" <?php endif; ?>>Event Manager</option>
                                <option value="Executive" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Executive"): ?> selected="" <?php endif; ?>>Executive</option>
                                <option value="Factory worker" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Factory worker"): ?> selected="" <?php endif; ?>>Factory worker</option>
                                <option value="Farmer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Farmer"): ?> selected="" <?php endif; ?>>Farmer</option>
                                <option value="Fashion Designer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Fashion Designer"): ?> selected="" <?php endif; ?>>Fashion Designer</option>
                                <option value="Finance" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Finance"): ?> selected="" <?php endif; ?>>Finance</option>
                                <option value="Flight Attendant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Flight Attendant"): ?> selected="" <?php endif; ?>>Flight Attendant</option>
                                <option value="Freelancer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Freelancer"): ?> selected="" <?php endif; ?>>Freelancer</option>
                                <option value="Government Employee" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Government Employee"): ?> selected="" <?php endif; ?>>Government Employee</option>
                                <option value="Health Care" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Health Care"): ?> selected="" <?php endif; ?>>Health Care</option>
                                <option value="Home Maker" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Home Maker"): ?> selected="" <?php endif; ?>>Home Maker</option>
                                <option value="Hotel &amp; Restaurant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Hotel &amp; Restaurant"): ?> selected="" <?php endif; ?>>Hotel &amp; Restaurant</option>
                                <option value="Human Resources" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Human Resources"): ?> selected="" <?php endif; ?>>Human Resources</option>
                                <option value="Interior Designer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Interior Designer"): ?> selected="" <?php endif; ?>>Interior Designer</option>
                                <option value="Investment" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Investment"): ?> selected="" <?php endif; ?>>Investment</option>
                                <option value="IT/Telecom" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="IT/Telecom"): ?> selected="" <?php endif; ?>>IT/Telecom</option>
                                <option value="Journalist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Journalist"): ?> selected="" <?php endif; ?>>Journalist</option>
                                <option value="Lawyer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Lawyer"): ?> selected="" <?php endif; ?>>Lawyer</option>
                                <option value="Lecturer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Lecturer"): ?> selected="" <?php endif; ?>>Lecturer</option>
                                <option value="Legal" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Legal"): ?> selected="" <?php endif; ?>>Legal</option>
                                <option value="Manager" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Manager"): ?> selected="" <?php endif; ?>>Manager</option>
                                <option value="Marketing" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Marketing"): ?> selected="" <?php endif; ?>>Marketing</option>
                                <option value="Media" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Media"): ?> selected="" <?php endif; ?>>Media</option>
                                <option value="Medical" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Medical"): ?> selected="" <?php endif; ?>>Medical</option>
                                <option value="Medical Transcriptionist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Medical Transcriptionist"): ?> selected="" <?php endif; ?>>Medical Transcriptionist</option>
                                <option value="Merchant Naval Officer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Merchant Naval Officer"): ?> selected="" <?php endif; ?>>Merchant Naval Officer</option>
                                <option value="Model" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Model"): ?> selected="" <?php endif; ?>>Model</option>
                                <option value="Nurse" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Nurse"): ?> selected="" <?php endif; ?>>Nurse</option>
                                <option value="Occupational Therapist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Occupational Therapist"): ?> selected="" <?php endif; ?>>Occupational Therapist</option>
                                <option value="Optician" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Optician"): ?> selected="" <?php endif; ?>>Optician</option>
                                <option value="Pharmacist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Pharmacist"): ?> selected="" <?php endif; ?>>Pharmacist</option>
                                <option value="Physician Assistant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Physician Assistant"): ?> selected="" <?php endif; ?>>Physician Assistant</option>
                                <option value="Physicist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Physicist"): ?> selected="" <?php endif; ?>>Physicist</option>
                                <option value="Physiotherapist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Physiotherapist"): ?> selected="" <?php endif; ?>>Physiotherapist</option>
                                <option value="Pilot" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Pilot"): ?> selected="" <?php endif; ?>>Pilot</option>
                                <option value="Politician" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Politician"): ?> selected="" <?php endif; ?>>Politician</option>
                                <option value="Production" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Production"): ?> selected="" <?php endif; ?>>Production</option>
                                <option value="Professor" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Professor"): ?> selected="" <?php endif; ?>>Professor</option>
                                <option value="Psychologist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Psychologist"): ?> selected="" <?php endif; ?>>Psychologist</option>
                                <option value="Public Relations" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Public Relations"): ?> selected="" <?php endif; ?>>Public Relations</option>
                                <option value="Real Estate" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Real Estate"): ?> selected="" <?php endif; ?>>Real Estate</option>
                                <option value="Research Scholar" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Research Scholar"): ?> selected="" <?php endif; ?>>Research Scholar</option>
                                <option value="Retired Person" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Retired Person"): ?> selected="" <?php endif; ?>>Retired Person</option>
                                <option value="Retail" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Retail"): ?> selected="" <?php endif; ?>>Retail</option>
                                <option value="Sales" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Sales"): ?> selected="" <?php endif; ?>>Sales</option>
                                <option value="Scientist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Scientist"): ?> selected="" <?php endif; ?>>Scientist</option>
                                <option value="Self-employed Person" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Self-employed Person"): ?> selected="" <?php endif; ?>>Self-employed Person</option>
                                <option value="Social Worker" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Social Worker"): ?> selected="" <?php endif; ?>>Social Worker</option>
                                <option value="Software Consultant" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Software Consultant"): ?> selected="" <?php endif; ?>>Software Consultant</option>
                                <option value="Software Engineer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Software Engineer"): ?> selected="" <?php endif; ?>>Software Engineer</option>
                                <option value="Sportsman" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Sportsman"): ?> selected="" <?php endif; ?>>Sportsman</option>
                                <option value="Student" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Student"): ?> selected="" <?php endif; ?>>Student</option>
                                <option value="Teacher" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Teacher"): ?> selected="" <?php endif; ?>>Teacher</option>
                                <option value="Technician" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Technician"): ?> selected="" <?php endif; ?>>Technician</option>
                                <option value="Training" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Training"): ?> selected="" <?php endif; ?>>Training</option>
                                <option value="Transportation" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Transportation"): ?> selected="" <?php endif; ?>>Transportation</option>
                                <option value="Veterinary Doctor" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Veterinary Doctor"): ?> selected="" <?php endif; ?>>Veterinary Doctor</option>
                                <option value="Volunteer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Volunteer"): ?> selected="" <?php endif; ?>>Volunteer</option>
                                <option value="Web Designer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Web Designer"): ?> selected="" <?php endif; ?>>Web Designer</option>
                                <option value="Writer" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Writer"): ?> selected="" <?php endif; ?>>Writer</option>
                                <option value="Zoologist" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Zoologist"): ?> selected="" <?php endif; ?>>Zoologist</option>
                                <option value="Other" <?php if(!empty($datingProfile['occupation']) && $datingProfile['occupation']=="Other"): ?> selected="" <?php endif; ?>>Other</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Income: </strong></td>
                        <td align="left" valign="top">
                            <select name="income" style="width:208px; font-size: 14px; height: 25px;">
                                <option value="">Select</option>
                                <option value="Under $25,000" <?php if(!empty($datingProfile['income']) && $datingProfile['income']=="Under $25,000"): ?> selected="" <?php endif; ?>>Under $25,000</option>
                                <option value="$25,001-50,000" <?php if(!empty($datingProfile['income']) && $datingProfile['income']=="$25,001-50,000"): ?> selected="" <?php endif; ?>>$25,001-50,000</option>
                                <option value="$50,001-75,000" <?php if(!empty($datingProfile['income']) && $datingProfile['income']=="$50,001-75,000"): ?> selected="" <?php endif; ?>>$50,001-75,000</option>
                                <option value="$75,001-100,000" <?php if(!empty($datingProfile['income']) && $datingProfile['income']=="$75,001-100,000"): ?> selected="" <?php endif; ?>>$75,001-100,000</option>
                                <option value="$100,001-150,000" <?php if(!empty($datingProfile['income']) && $datingProfile['income']=="$100,001-150,000"): ?> selected="" <?php endif; ?>>$100,001-150,000</option>
                                <option value="$150,001-200,000" <?php if(!empty($datingProfile['income']) && $datingProfile['income']=="$150,001-200,000"): ?> selected="" <?php endif; ?>>$150,001-200,000</option>
                                <option value="$200,001 and above" <?php if(!empty($datingProfile['income']) && $datingProfile['income']=="$200,001 and above"): ?> selected="" <?php endif; ?>>$200,001 and above</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><h6 class="inner">About Myself</h6></td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> About Myself: * </strong></td>
                        <td align="left" valign="top">
                            <textarea name="about_myself" style="width:208px; font-size: 14px; height: 60px;"><?php if(!empty($datingProfile['about_myself'])): ?> <?php echo e($datingProfile['about_myself']); ?> <?php endif; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><h6 class="inner">About My Preferred Partner</h6></td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" class="body"><strong> Partner Details: * </strong></td>
                        <td align="left" valign="top">
                            <textarea name="about_partner" style="width:208px; font-size: 14px; height: 60px;"><?php if(!empty($datingProfile['about_partner'])): ?> <?php echo e($datingProfile['about_partner']); ?> <?php endif; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="submit" class="button" value="Submit" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    <div class="clear"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>