<?php /* F:\xampp\htdocs\laravel\dating5.8\resources\views/users/sent_messages.blade.php */ ?>
<?php use App\User; ?>

<?php $__env->startSection('content'); ?>
<div id="right_container">
    <div style="padding:20px 15px 30px 15px;">
        <h1>Sent Messages</h1>
        <table id="responses" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Location</th>
                <th>Response</th>
                <th>Date/Time</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sent_msg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $receiver_name = User::getName($msg->receiver_id);
            $receiver_city = User::getCity($msg->receiver_id);
            ?>
            <tr align="center">
                <td><?php echo e($receiver_name); ?></td>
                <td><?php echo e($receiver_city); ?></td>
                <td><?php echo e($msg->message); ?></td>
                <td><?php echo e($msg->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <div class="clear"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>