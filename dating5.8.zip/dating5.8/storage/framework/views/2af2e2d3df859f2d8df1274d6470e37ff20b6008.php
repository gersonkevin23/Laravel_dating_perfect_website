<?php $__env->startSection('content'); ?>
  <div id="right_container">
        <div style="padding:20px 15px 30px 15px;">
          <h1>Contact <?php echo e($userDetails->name); ?></h1>
          <?php $__currentLoopData = $userDetails->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($photo->default_photo == "Yes"): ?>
              <?php $user_photo = $userDetails->photos[$key]->photo; ?>
            <?php else: ?>
              <?php $user_photo = $userDetails->photos[0]->photo; ?>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div>
            <?php if(!empty($user_photo)): ?>
              <img src="<?php echo e(asset('images/frontend_images/photos/'.$user_photo)); ?>" alt="" width="210" class="aboutus-img" />
            <?php else: ?>
              <img src="<?php echo e(asset('images/frontend_images/photos/default.jpg')); ?>" alt="" width="210" class="aboutus-img" />
            <?php endif; ?>  
            <strong>Profile ID:</strong> <?php echo e($userDetails->username); ?><br>
            <strong>Name:</strong> <?php echo e($userDetails->name); ?><br>
            <strong>Gender:</strong> <?php echo e($userDetails->details->gender); ?><br>
            <strong>Marital Status:</strong> <?php echo e($userDetails->details->marital_status); ?><br>
            <strong>Age:</strong> <?php
                      echo $diff = date('Y') - date('Y',strtotime($userDetails->details->dob)); 
                    ?> Yrs.<br>
            <strong>Height:</strong> <?php echo e($userDetails->details->height); ?><br>
            <strong>Body Type:</strong> <?php echo e($userDetails->details->body_type); ?><br>
            <strong>Complexion:</strong> <?php echo e($userDetails->details->complexion); ?><br>
            <strong>Languages:</strong> <?php echo e($userDetails->details->languages); ?><br>
            <strong>Hobbies:</strong> <?php echo e($userDetails->details->hobbies); ?><br>
            <strong>City:</strong> <?php echo e($userDetails->details->city); ?><br>
            <strong>State:</strong> <?php echo e($userDetails->details->state); ?><br>
            <strong>Country:</strong> <?php echo e($userDetails->details->country); ?><br>
            <strong style="float:right;">
              <script type="text/javascript">
                  var viewer = new PhotoViewer();
                  <?php $__currentLoopData = $userDetails->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    viewer.add('/images/frontend_images/photos/<?php echo $userDetails->photos[$key]->photo ?>');
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </script>
                <a href="javascript:void(viewer.show(0))">Photo Album</a>
            </strong><br>
            <form>
              <textarea></textarea><br>
              <input type="submit" name="" value="Send Message">
            </form>
            <br />
            <br />
            <div class="clear"></div>
          </div>       
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>